package com.tweetapp;

import java.util.Scanner;
import com.tweetapp.NewUserAction;
import com.tweetapp.service.LoggedInUserAction;

public class MainMenu {
	public static boolean isUserLoggedIn =false;
	public static String loggedUsername = null;
	 
	
	public static void MyApplication() {
		Scanner scan = new Scanner(System.in);
		int answer = 0;
		System.out.println("Let's enter the TweetApp !\n");
		
		while(answer!=4) {
			answer = openMenu();
			switch(answer) {
				case 1: NewUserAction.register(); break;
				case 2: loggedUsername = NewUserAction.login(); break;
				case 3: NewUserAction.forgotPassword(); break;
			}
			if(answer == 2 && isUserLoggedIn) {
				int userOption = 0;
				while(isUserLoggedIn) {
					userOption = showLoggedInUserMenu(loggedUsername);
					switch(userOption) {
						case 1: LoggedInUserAction.postATweet(loggedUsername); break;
						case 2: LoggedInUserAction.fetchTweetsByUsername(loggedUsername); break;
						case 3: LoggedInUserAction.fetchAllTweets(); break;
						case 4: LoggedInUserAction.fetchAllUsers(); break;
						case 5: LoggedInUserAction.resetPassword(loggedUsername); break;
						default:isUserLoggedIn = false;
					}
				}
			}
		}
		scan.close();
		System.out.println("Thankyou for being on TweetApp !!");
	}
	
	public static int openMenu() {
		
		System.out.println("\n**************     ***************"
				+ "\nSelect option from the menu:: \n1. Register yourself"
				+ "  2. Login"
				+ "  3. Forgot Password"
				+ "  4. Exit"
				+ "\n \n Pick one option to continue");
		
		Scanner scan =new Scanner(System.in);
		String strValue = scan.next();
		try {
			int option = Integer.parseInt(strValue);
			if(option <=0 && option>=5) {
				throw new NumberFormatException();
			}
			
			return option;			
		}catch(NumberFormatException e) {
			System.out.println("Invalid Option! Please select a valid option");
		}
		return -1;
	}
	
	public  static int showLoggedInUserMenu(String username) {
		System.out.println("Hi "+username+",");
		System.out.println("Menu : \n1. Post a tweet"
				+ "\n2. View my tweets"
				+ "\n3. View all tweets"
				+ "\n4. View All Users"
				+ "\n5. Reset Password"
				+ "\n6. Logout"
				+ "\n Please select an option to continue");
		Scanner scan = new Scanner(System.in);
		String strValue = scan.next();
		try {
			int option = Integer.parseInt(strValue);
			if(option <=0 && option>=7) {
				throw new NumberFormatException();
			}
			return option;			
		}catch(NumberFormatException e) {
			System.out.println("Invalid Option! Please select a valid option");
		}
		return -1;
	}

}


